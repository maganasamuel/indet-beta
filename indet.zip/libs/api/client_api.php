<?php

/**
@name: leadGenerator_api.php
@author: Jesse
@desc:
	Serves as the API of the admins
	This page handles all asynchronous javascript request from the above mentioned page
@returnType:
	JSON
 */
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
if (!isset($_SESSION)) session_start();


if (file_exists("controllers/Client.controller.php"))          //for Controllers in libs
    include_once("controllers/Client.controller.php");

//fetch POST request parameter 
$action = $_POST["action"];

//determine which function to trigger
switch ($action) {
    case "":
    default:
        echo json_encode(array("message" => "invalid request"));
        break;
    case "get_clients":
        echo getAllClients();
        break;
    case "get_clients":
        echo getAllClients();
        break;
    case "get_client":
        echo GetClient();
        break;
    case "get_client_and_fetch":
        echo GetClientAndFetch();
        break;
    case "create_client":
        echo CreateClient();
        break;
    case "update_client":
        echo UpdateClient();
        break;
    case "delete_client":
        echo DeleteClient();
        break;
    case "create_send_client_data_entry":
        echo CreateSendClientDataEntry();
        break;
    case "create_send_issued_client_data_entry":
        echo CreateSendIssuedClientDataEntry();
        break;
    case "send_client_data":
        echo SendClientData();
        break;
}

/**
	@desc: delete the Resource
 */

function GetAllClients()
{
    $controller = new ClientController();
    extract($_POST);

    $dataset = $controller->getAllClients();
    $op = array();

    while ($data = $dataset->fetch_assoc()) {
        $op[] = $data;
    }

    return json_encode($op);
}


/**
	@desc: delete the Resource
 */

function GetClient()
{
    $controller = new ClientController();
    extract($_POST);

    $data = $controller->getClient($client_id);

    return json_encode($data);
}


/**
	@desc: delete the Resource
 */

function GetClientAndFetch()
{
    $controller = new ClientController();
    extract($_POST);

    $data = $controller->getClient($client_id);

    return json_encode($data);
}

/**
	@desc: CreateClients the Resource
 */

function CreateClient()
{
    $controller = new ClientController();
    extract($_POST);

    $data = $controller->createClient(
        $team_id,
        $name,
        $company_name,
        $payroll_name,
        $fsp_num,
        $address,
        $email,
        $birthday,
        $leads,
        $bonus
    );

    $data = $data->fetch_assoc();
    $data["birthday"] = date("d/m/Y", strtotime($data["birthday"]));

    return json_encode($data);
}

/**
	@desc: UpdateClient the Resource
 */

function UpdateClient()
{
    $controller = new ClientController();
    extract($_POST);

    $data = $controller->updateClient(
        $client_id,
        $team_id,
        $name,
        $company_name,
        $payroll_name,
        $fsp_num,
        $address,
        $email,
        $birthday,
        $leads,
        $bonus
    );
    $data = $data->fetch_assoc();
    $data["birthday"] = date("d/m/Y", strtotime($data["birthday"]));

    return json_encode($data);
}

/**
	@desc: delete the Resource
 */

function DeleteClient()
{
    $controller = new ClientController();
    extract($_POST);

    $data = $controller->deleteClient($client_id);

    return json_encode($data);
}

/**
	@desc: create send client data entry
 */

function CreateSendClientDataEntry()
{
    $controller = new ClientController();
    extract($_POST);

    $data = $controller->createSendClientDataEntry($name, $email, $client_ids);

    return json_encode($data);
}


/**
	@desc: create send client data entry
 */

function CreateSendIssuedClientDataEntry()
{
    $controller = new ClientController();
    extract($_POST);

    $data = $controller->createSendIssuedClientDataEntry($name, $email, $client_ids);

    return json_encode($data);
}

/**
	@desc: delete the Resource
 */

function SendClientData()
{
    $controller = new ClientController();
    extract($_POST);

    //$data = $controller->createSendClientDataEntry($send_client_data_id);

    return json_encode($data);
}
